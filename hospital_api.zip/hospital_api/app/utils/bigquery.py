from google.cloud import bigquery
import os

# Set environment variable for Google Cloud credentials
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/path/to/your/credentials.json"

def update_patients_from_bigquery():
    # Create a BigQuery client
    client = bigquery.Client()

    # Define your BigQuery SQL query
    query = """
    SELECT
        no_ktp,
        name,
        birthdate,
        gender
    FROM
        `delman-internal.delman_interview.vaccine_data`
    """

    # Run the query and get the results
    query_job = client.query(query)
    results = query_job.result()

    # Process the results
    for row in results:
        # Example: print each row (customize this part to update your database)
        print(f"no_ktp: {row.no_ktp}, name: {row.name}, birthdate: {row.birthdate}, gender: {row.gender}")

        # Here you would typically update your local database with the results
        # For example, you might use SQLAlchemy to add/update records in your database
        # Example (pseudo-code):
        # patient = Patient.query.filter_by(no_ktp=row.no_ktp).first()
        # if patient:
        #     patient.name = row.name
        #     patient.birthdate = row.birthdate
        #     patient.gender = row.gender
        # else:
        #     patient = Patient(no_ktp=row.no_ktp, name=row.name, birthdate=row.birthdate, gender=row.gender)
        #     db.session.add(patient)
        # db.session.commit()
